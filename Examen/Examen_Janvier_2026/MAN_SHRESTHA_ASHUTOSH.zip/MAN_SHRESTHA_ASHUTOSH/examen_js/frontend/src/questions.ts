const questions: string[] = [
    "Quels sont selon vous les points forts de notre service ?",
    "Quels aspects de notre service pourraient être améliorés ?",
    "Y a-t-il des fonctionnalités ou des services supplémentaires que vous aimeriez voir ?",
];