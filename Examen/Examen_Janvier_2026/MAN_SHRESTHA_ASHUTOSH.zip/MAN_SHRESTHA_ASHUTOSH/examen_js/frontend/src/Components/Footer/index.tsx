import "./Footer.css";

const Footer = () => {
  return (
    <footer>
      <h1>
        Ashutosh Man Shrestha
      </h1>
    </footer>
  );
};

export default Footer;
